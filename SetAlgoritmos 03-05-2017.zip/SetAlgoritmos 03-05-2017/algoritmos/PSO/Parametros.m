%%Parametros
C1=2;
C2=2;
Vmax=0.1;
Vmin=0.0;

%%Cadena indicando condiciones del algoritmo (aunque deber�an de ser propias por cada uno)
Cond_Algoritmo=sprintf('Se propone C1=%2.2f, C2=%2.2f, Vmax=%2.2f y Vmin=%2.2f constantes',C1,C2,Vmax,Vmin);
