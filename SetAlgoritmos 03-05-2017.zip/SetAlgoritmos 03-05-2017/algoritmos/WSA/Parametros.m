%%Parametros
V=1.2;
S=5.6;
Pa=0.4;
Alpha=0.25;

%%Cadena indicando condiciones del algoritmo (aunque deber�an de ser propias por cada uno)
Cond_Algoritmo=sprintf('Se propone V=%2.2f, S=%2.2f, Pa=%2.2f y Alpha=%2.2f constantes',V,S,Pa,Alpha);
