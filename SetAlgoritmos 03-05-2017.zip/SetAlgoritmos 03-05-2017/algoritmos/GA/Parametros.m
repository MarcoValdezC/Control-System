%%Parametros
TS=15;
CR=0.5;
F=0.5;
%%Cadena indicando condiciones del algoritmo (aunque deber�an de ser propias por cada uno)
Cond_Algoritmo=sprintf('Se propone TS=%2.2f, CR=%2.2f y F=%2.2f constantes',TS,CR,F);
