%%Parametros
Alpha=0.5;
Betamin=2.5;
Gamma=0.1;
%%Cadena indicando condiciones del algoritmo (aunque deber�an de ser propias por cada uno)
Cond_Algoritmo=sprintf('Se propone Alpha=%2.2f, Beta_min=%2.2f y Gamma=%2.2f constantes',Alpha,Betamin,Gamma);
