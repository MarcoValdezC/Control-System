%% f(x*)=f(1,1,1)=0
MAX_V=10000;
D_MAX = [MAX_V, MAX_V, MAX_V];
D_MIN = [-MAX_V, -MAX_V, -MAX_V];
