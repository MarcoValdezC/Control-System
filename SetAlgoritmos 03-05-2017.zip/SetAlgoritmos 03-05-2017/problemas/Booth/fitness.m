function f = fitness(x)
f=(x(1) + 2*x(2) - 7)^2 ...
    + (2*x(1) + x(2) - 5)^2;
end
