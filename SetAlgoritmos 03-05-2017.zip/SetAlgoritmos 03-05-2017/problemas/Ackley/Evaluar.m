function [fitnessValue,violationCount]=Evaluar(x)

%% Evalua funcion objetivo
fitnessValue=fitness(x);
%% Evalua restricciones
violationCount=0;
end
